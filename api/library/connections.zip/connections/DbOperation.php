<?php
	class DbOperation
	{
		private $conn;
		
		function __construct()
		{
			require_once dirname(__FILE__) . '/conn.php';
			
			$db=new DbConnect();
			$this->conn=$db->connect();
		}
		
		public function getCustomer()
		{
			$stmt=$this->conn->prepare("select * from customer");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerID()
		{
			$stmt=$this->conn->prepare("select custID from customer ORDER BY custID DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerNoticeID()
		{
			$stmt=$this->conn->prepare("select cNID from custnotice ORDER BY cNID DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSmsByPhone($phoneNo)
		{
			$params=array(
			':phoneNo'=>$phoneNo
			);
		
			$stmt=$this->conn->prepare("select * from sms where phone='$phoneNo' order by id desc limit 1");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerByPhone($phoneNo)
		{
			$params=array(
			':phoneNo'=>$phoneNo
			);
		
			$stmt=$this->conn->prepare("select * from customer where custTel=:phoneNo");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerByDevice($custDevice)
		{
			$params=array(
			':custDevice'=>password_hash($custDevice, PASSWORD_BCRYPT)
			);
		
			$stmt=$this->conn->prepare("select * from customer where custDevice=:custDevice");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function createCust($custID,$custDevice,$custTel)
		{
			$params=array(
			':custID'=>$custID,
			':custDevice'=>password_hash($custDevice,PASSWORD_BCRYPT),
			':custTel'=>$custTel
			);
			
			$stmt=$this->conn->prepare("insert into customer(custID,custDevice,custTel) values (:custID,:custDevice,:custTel)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
			}else{
				return false;
			}
		}
		
		public function createSMS($phone,$verifyCode)
		{
			$params=array(
			':phone'=>$phone,
			':verifyCode'=>$verifyCode
			);
			
			$stmt=$this->conn->prepare("insert into sms(phone,verifyCode) values (:phoneNo,:verifyCode)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
			}else{
				return false;
			}
		}
		
		public function createCustomerNotice($cNID,$custID,$title,$titleEng,$description,$descriptionEng)
		{
			$params=array(
			':cNID'=>$cNID,
			':custID'=>$custID,
			':title'=>$title,
			':titleEng'=>$titleEng,
			':description'=>$description,
			':descriptionEng'=>$descriptionEng
			);
			
			$stmt=$this->conn->prepare("
			insert into custnotice(cNID,custID,title,titleEng,description,descriptionEng) values 
			(:cNID,:custID,:title,:titleEng,:description,:descriptionEng)"; 
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
			}else{
				return false;
			}
		}
		
		public function deleteSmsByPhone($phone)
		{
			$params=array(
			':phone'=>$phone
			);
			
			$stmt=$this->conn->prepare("delete from sms where phone=:phone");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
			}else{
				return false;
			}
		}
	}
?>