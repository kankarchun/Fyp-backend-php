<?php
	class DbOperation
	{
		private $conn;
		private $today;
		
		function __construct()
		{
			require_once dirname(__FILE__) . '/conn.php';
			
			$db=new DbConnect();
			$this->conn=$db->connect();
			
			date_default_timezone_set('Asia/Hong_Kong');
			$this->today = date('Y/m/d H:i:s', time());
			
			set_exception_handler('errorBlock');
		}
		
		public function __call($name, $args)
		{
			$name = $name . "_" . implode("_", array_map("gettype", $args)));
			return call_user_func_array(array($this, $name), $args);
		}
		
		public function errorBlock($e)
		{
			$msg=array('result'=>500,'message'=>"sql error",'data'=>$ex->getMessage());
			echo json_encode($msg, JSON_UNESCAPED_UNICODE);
			return false;
		}
		
		public function getAllCustomer()
		{
			$stmt=$this->conn->prepare("select * from customer");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerID()
		{
			$stmt=$this->conn->prepare("select custID from customer 
			ORDER BY custID DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerNoticeID()
		{
			$stmt=$this->conn->prepare("select cNID from custnotice 
			ORDER BY cNID DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSmsByPhone($phoneNo)
		{
			$params=array(
			':phoneNo'=>$phoneNo
			);
			
			$stmt=$this->conn->prepare("select * from sms where
			phone=:phoneNo' order by id desc limit 1");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerByPhone($phoneNo)
		{
			$params=array(
			':phoneNo'=>$phoneNo
			);
			
			$stmt=$this->conn->prepare("select * from customer where 
			custTel=:phoneNo");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerByDevice($custDevice)
		{
			$params=array(
			':custDevice'=>password_hash($custDevice, PASSWORD_BCRYPT)
			);
			
			$stmt=$this->conn->prepare("select * from customer where
			custDevice=:custDevice");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getRestaurantCharge($restID)
		{
			$params=array(
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from charge where 
			restID=:restID and hide='0'
			order by orderIn");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteRestaurant($custID,$restID)
		{
			$params=array(
			':custID'=>$custID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from favourite where
			custID=:custID and restID=:restID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteFood($custID,$foodID)
		{
			$params=array(
			':custID'=>$custID,
			':foodID'=>$foodID
			);
			
			$stmt=$this->conn->prepare("select * from favouritefood where 
			custID=:custID and foodID=:foodID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteFood($custID,$setID)
		{
			$params=array(
			':custID'=>$custID,
			':setID'=>$setID
			);
			
			$stmt=$this->conn->prepare("select * from favouriteset where
			custID=:custID and setID=:setID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerFavouriteRestaurant($custID)
		{
			$params=array(
			':custID'=>$custID
			);
			
			$stmt=$this->conn->prepare("select * from favourite where 
			custID=:custID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getRestaurant($restID)
		{
			$params=array(
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from restcompany,restaurant,region where
			region.rgid=restaurant.rgid and
			restcompany.companyID=restaurant.companyID and 
			restaurant.restID=:restID and
			restaurant.locked=0 and
			restcompany.locked=0");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerFavouriteFood($custID,$restID)
		{
			$params=array(
			':custID'=>$custID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("
			select * from restaurant,favouritefood,restcompany,menugroup,menugroupitem where
			menugroup.groupNo=menugroupitem.groupNo and
			menugroup.restID=menugroupitem.restID and
			menugroupitem.foodID=favouritefood.foodID and
			restcompany.companyID=restaurant.companyID and
			restaurant.restID=favouritefood.restID and
			favouritefood.custID=:custID and 
			favouritefood.restID=:restID and 
			restaurant.locked=0 and
			restcompany.locked=0");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getMenuItemFood($foodID,$restID)
		{
			$params=array(
			':foodID'=>$foodID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from food,menugroupitem where 
			menugroupitem.foodID=food.foodID and 
			available=0 and 
			food.foodID=:foodID and
			food.restID=:restID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteOrderOption($ffID)
		{
			$params=array(
			':ffID'=>$ffID
			);
			
			$stmt=$this->conn->prepare("select * from favouriteorderoption where
			ffID=:ffID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSpecialOption($optID)
		{
			$params=array(
			':optID'=>$optID
			);
			
			$stmt=$this->conn->prepare("select * from specialoption where 
			optID=:optID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerFavouriteSet($custID,$restID)
		{
			$params=array(
			':custID'=>$custID,
			':optID'=>$optID
			);
			
			$stmt=$this->conn->prepare("
			select * from restaurant,favouriteset,restcompany,menugroup,menugroupitem where 
			menugroup.groupNo=menugroupitem.groupNo and 
			menugroup.restID=menugroupitem.restID and 
			menugroupitem.setID=favouriteset.setID and
			restcompany.companyID=restaurant.companyID and
			restaurant.restID=favouriteset.restID and
			custID=:custID and 
			favouriteset.restID=:restID and
			restaurant.locked=0 and 
			restcompany.locked=0");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getMenuItemFood($setID,$restID)
		{
			$params=array(
			':setID'=>$setID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from setitem,menugroupitem where 
			menugroupitem.setID=setitem.setID and 
			available=0 and 
			setitem.setID=:setID and
			setitem.restID=:restID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSetTitle($setID)
		{
			$params=array(
			':setID'=>$setID
			);
			
			$stmt=$this->conn->prepare("select * from settitle where 
			setID=:setID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerFavouriteSetChoice($fsID,$custID)
		{
			$params=array(
			':fsID'=>$fsID,
			':custID'=>$custID
			);
			
			$stmt=$this->conn->prepare("select * from favouritesetchoice where
			fsID=:fsID and
			custID=:custID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getMenuItemSetFood($titleNo)
		{
			$params=array(
			':titleNo'=>$titleNo
			);
			
			$stmt=$this->conn->prepare("select * from food,setfood,menugroupitem where
			menugroupitem.foodID=food.foodID and
			available=0 and 
			food.foodID=setfood.foodID and 
			setfood.titleNo=:titleNo");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteChoiceOption($fscID)
		{
			$params=array(
			':fscID'=>$fscID
			);
			
			$stmt=$this->conn->prepare("select * from favouritechoiceoption where 
			fscID=:fscID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getMenuItemSetFood($setID,$titleNo)
		{
			$params=array(
			':setID'=>$setID,
			':titleNo'=>$titleNo
			);
			
			$stmt=$this->conn->prepare("select * from food,setfood,menugroupitem where
			menugroupitem.foodID=food.foodID and
			available=0 and 
			food.foodID=setfood.foodID and 
			setfood.setID=:setID and
			setfood.titleNo=:titleNo");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getOptionAllow($foodID)
		{
			$params=array(
			':foodID'=>$foodID
			);
			
			$stmt=$this->conn->prepare("select * from specialoption where 
			optid in (select optid from optionallow where 
			foodID=:foodID)");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerInvoice($custID)
		{
			$params=array(
			':custID'=>$custID
			);
			
			$stmt=$this->conn->prepare("select * from invoice where 
			custID=:custID
			order by orderDateTime desc");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getInvoiceTakeout($invoiceID)
		{
			$params=array(
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("select * from takeout where 
			invoiceID=:invoiceID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerById($custID)
		{
			$params=array(
			':custID'=>$custID
			);
			
			$stmt=$this->conn->prepare("select * from customer where 
			custID=:custID and 
			locked=0");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getRestaurantTable($tableID)
		{
			$params=array(
			':tableID'=>$tableID
			);
			
			$stmt=$this->conn->prepare("select * from resttable where 
			tableID=:tableID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getInvoiceCharge($invoiceID)
		{
			$params=array(
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("select * from invoicecharge where 
			invoiceID=:invoiceID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getOrderFood($invoiceID)
		{
			$params=array(
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("select * from orderfood where 
			invoiceID=:invoiceID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getOrderOption($orderNo,$invoiceID)
		{
			$params=array(
			':orderNo'=>$orderNo,
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("select * from orderoption where
			orderNo=:orderNo and 
			invoiceID=:invoiceID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSetOrder($invoiceID)
		{
			$params=array(
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("select * from setorder where 
			invoiceID=:invoiceID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSetOrderChoice($setOrderNo,$invoiceID)
		{
			$params=array(
			':setOrderNo'=>$setOrderNo,
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("select * from setorderchoice where 
			setOrderNo=:setOrderNo and invoiceID=:invoiceID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getChoiceOption($setOrderChoiceNo,$setOrderNo,$invoiceID)
		{
			$params=array(
			':setOrderChoiceNo'=>$setOrderChoiceNo,
			':setOrderNo'=>$setOrderNo,
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("select * from choiceoption where
			setOrderChoiceNo=:setOrderChoiceNo and 
			setOrderNo=:setOrderNo and 
			invoiceID=:invoiceID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getInvoiceId()
		{
			$stmt=$this->conn->prepare("select invoiceID from invoice
			ORDER BY invoiceID DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getTakeoutId()
		{
			$stmt=$this->conn->prepare("select takeoutID from takeout
			ORDER BY takeoutID DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getRestaurantTable($restID,$tableID)
		{
			$params=array(
			':restID'=>$restID,
			':tableID'=>$tableID
			);
			
			$stmt=$this->conn->prepare("select * from restaurant,resttable where
			restaurant.restID=resttable.restID and
			restaurant.restID=:restID and
			resttable.tableID=:tableID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}		
		
		public function getInvoiceTableNo()
		{
			$stmt=$this->conn->prepare("select * from invoice where
			tableID is null and 
			orderDateTime>CURDATE()");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}	
		
		public function getOrderFoodNo()
		{
			$stmt=$this->conn->prepare("select orderNo from orderfood
			ORDER BY orderNo DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}	
		
		public function getFood($foodID)
		{
			$params=array(
			':foodID'=>$foodID
			);
			
			$stmt=$this->conn->prepare("select * from food where
			foodID=:foodID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}	
		
		public function getSetOrderNo()
		{
			$stmt=$this->conn->prepare("select setOrderNo from setorder 
			ORDER BY setOrderNo DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}	
		
		public function getSetItem($setID)
		{
			$params=array(
			':setID'=>$setID
			);
			
			$stmt=$this->conn->prepare("select * from setitem where 
			setID=:setID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSetOrderChoiceNo()
		{
			$stmt=$this->conn->prepare("select setOrderChoiceNo from setorderchoice
			ORDER BY setOrderChoiceNo DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}	
		
		public function getSetFood($foodNo)
		{
			$params=array(
			':foodNo'=>$foodNo
			);
			
			$stmt=$this->conn->prepare("select * from setfood,food where
			setfood.foodID=food.foodID and 
			foodNo=:foodNo");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getInvoiceChargeNo()
		{
			$stmt=$this->conn->prepare("select iChargeNo from invoicecharge 
			ORDER BY iChargeNo DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCharge($chargeID)
		{
			$params=array(
			':chargeID'=>$chargeID
			);
			
			$stmt=$this->conn->prepare("select * from charge where
			chargeID=:chargeID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getInvoice($invoiceID)
		{
			$params=array(
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("select * from invoice where
			invoiceID=:invoiceID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function createCust($custID,$custDevice,$custTel)
		{
			$params=array(
			':custID'=>$custID,
			':custDevice'=>password_hash($custDevice,PASSWORD_BCRYPT),
			':custTel'=>$custTel
			);
			
			$stmt=$this->conn->prepare("insert into customer(custID,custDevice,custTel) values 
			(:custID,:custDevice,:custTel)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createSMS($phone,$verifyCode)
		{
			$params=array(
			':phone'=>$phone,
			':verifyCode'=>$verifyCode
			);
			
			$stmt=$this->conn->prepare("insert into sms(phone,verifyCode) values 
			(:phoneNo,:verifyCode)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createCustomerNotice($cNID,$custID,$title,$titleEng,$description,$descriptionEng)
		{
			$params=array(
			':cNID'=>$cNID,
			':custID'=>$custID,
			':title'=>$title,
			':titleEng'=>$titleEng,
			':description'=>$description,
			':descriptionEng'=>$descriptionEng
			);
			
			$stmt=$this->conn->prepare("
			insert into custnotice(cNID,custID,title,titleEng,description,descriptionEng) values 
			(:cNID,:custID,:title,:titleEng,:description,:descriptionEng)"; 
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createInvoiceOfTable($invoiceID,$restID,$custID,$tableID)
		{
			$params=array(
			':invoiceID'=>$invoiceID,
			':restID'=>$restID,
			':custID'=>$custID,
			':tableID'=>$tableID
			);
			
			$stmt=$this->conn->prepare("
			insert into invoice(invoiceID,restID,custID,tableID,foodTotalCost,totalCost,orderDateTime) values 
			(:invoiceID,:restID,:custID,:tableID,0,0,'$this->today')");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createInvoiceOfTakeout($invoiceID,$restID,$custID,$takeoutID)
		{
			$params=array(
			':invoiceID'=>$invoiceID,
			':restID'=>$restID,
			':custID'=>$custID,
			':takeoutID'=>$takeoutID
			);
			
			$stmt=$this->conn->prepare("
			insert into invoice(invoiceID,restID,custID,takeoutID,foodTotalCost,totalCost,orderDateTime) values 
			(:invoiceID,:restID,:custID,:takeoutID,0,0,'$this->today')");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createTakeoutOfAddress($takeoutID,$address,$invoiceID)
		{
			$params=array(
			':takeoutID'=>$takeoutID,
			':address'=>$address,
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("
			insert into takeout(takeoutID,address,invoiceID) values 
			(:takeoutID,:address,:invoiceID)";
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createTakeoutOfNo($takeoutID,$takeoutNo,$invoiceID)
		{
			$params=array(
			':takeoutID'=>$takeoutID,
			':takeoutNo'=>$takeoutNo,
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("
			insert into takeout(takeoutID,takeoutNo,invoiceID) values
			(:takeoutID,:takeoutNo,:invoiceID)");

			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createOrderFood($orderNo,$invoiceID,$foodChiName,$foodEngName,$foodPrice,$quantity)
		{
			$params=array(
			':orderNo'=>$orderNo,
			':invoiceID'=>$invoiceID,
			':foodChiName'=>$foodChiName,
			':foodEngName'=>$foodEngName,
			':foodPrice'=>$foodPrice,
			':quantity'=>$quantity
			);
			
			$stmt=$this->conn->prepare("
			insert into orderfood(orderNo,invoiceID,foodChiName,foodEngName,foodPrice,quantity,foodSubPrice) values
			(:orderNo,:invoiceID,:foodChiName,:foodEngName,:foodPrice,:quantity,0)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createOrderOption($optID,$orderNo,$invoiceID)
		{
			$params=array(
			':optID'=>$optID,
			':orderNo'=>$orderNo,
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("
			insert into orderoption(optID,orderNo,invoiceID) values 
			(:optID,:orderNo,:invoiceID)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createSetOrder($setOrderNo,$invoiceID,$setChiName,$setEngName,$setPrice,$quantity)
		{
			$params=array(
			':setOrderNo'=>$setOrderNo,
			':invoiceID'=>$invoiceID,
			':setChiName'=>$setChiName,
			':setEngName'=>$setEngName,
			':setPrice'=>$setPrice,
			':quantity'=>$quantity
			);
			
			$stmt=$this->conn->prepare("
			insert into setorder(setOrderNo,invoiceID,setChiName,setEngName,setPrice,quantity,setSubPrice) values
			(:setOrderNo,:invoiceID,:setChiName,:setEngName,:setPrice,:quantity,0)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createSetOrderChoice($setOrderChoiceNo,$setOrderNo,$invoiceID,$foodChiName,$foodEngName,$extraPrice,$quantity,$extraSubPrice)
		{
			$params=array(
			':setOrderChoiceNo'=>$setOrderChoiceNo,
			':setOrderNo'=>$setOrderNo,
			':invoiceID'=>$invoiceID,
			':foodChiName'=>$foodChiName,
			':foodEngName'=>$foodEngName,
			':extraPrice'=>$extraPrice,
			':quantity'=>$quantity,
			':extraSubPrice'=>$extraSubPrice
			);
			
			$stmt=$this->conn->prepare("
			insert into setorderchoice(setOrderChoiceNo,setOrderNo,invoiceID,foodChiName,foodEngName,extraPrice,quantity,extraSubPrice) values 
			(:setOrderChoiceNo,:setOrderNo,:invoiceID,:foodChiName,:foodEngName,:extraPrice,:quantity,:extraSubPrice)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createChoiceOption($optID,$setOrderChoiceNo,$setOrderNo,$invoiceID)
		{
			$params=array(
			':optID'=>$optID,
			':setOrderChoiceNo'=>$setOrderChoiceNo,
			':setOrderNo'=>$setOrderNo,
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("
			insert into choiceoption(optID,setOrderChoiceNo,setOrderNo,invoiceID) values
			(:optID,:setOrderChoiceNo,:setOrderNo,:invoiceID)");

			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createInvoiceCharge($iChargeNo,$invoiceID,$detailChi,$charge)
		{
			$params=array(
			':iChargeNo'=>$iChargeNo,
			':invoiceID'=>$invoiceID,
			':detailChi'=>$detailChi,
			':detailEng'=>$detailEng,
			':charge'=>$charge
			);
			
			$stmt=$this->conn->prepare("
			insert into invoicecharge(iChargeNo,invoiceID,detailChi,detailEng,charge) values
			(:iChargeNo,:invoiceID,:detailChi,:detailEng,:charge)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function updateTable($tableID)
		{
			$params=array(
			':tableID'=>$tableID
			);
			
			$stmt=$this->conn->prepare("update resttable set 
			tableLock=0 where 
			tableID=:tableID");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function updateOrderFoodPrice($foodSubPrice,$orderNo)
		{
			$params=array(
			':foodSubPrice'=>$foodSubPrice,
			':orderNo'=>$orderNo
			);
			
			$stmt=$this->conn->prepare("update orderfood set 
			foodSubPrice=:foodSubPrice where 
			orderNo=:orderNo");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function updateSetOrderPrice($setSubPrice,$setOrderNo)
		{
			$params=array(
			':setSubPrice'=>$setSubPrice,
			':setOrderNo'=>$setOrderNo
			);
			
			$stmt=$this->conn->prepare("update setorder set 
			setSubPrice=:setSubPrice where
			setOrderNo=:setOrderNo");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function updateInvoicePrice($totalCost,$foodTotalCost,$invoiceID)
		{
			$params=array(
			':totalCost'=>$totalCost,
			':foodTotalCost'=>$foodTotalCost,
			':invoiceID'=>$invoiceID
			);
			
			$stmt=$this->conn->prepare("update invoice set 
			totalCost=:totalCost,
			foodTotalCost=:foodTotalCost where
			invoiceID=:invoiceID");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function deleteSmsByPhone($phone)
		{
			$params=array(
			':phone'=>$phone
			);
			
			$stmt=$this->conn->prepare("delete from sms where 
			phone=:phone");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function deleteFavouriteRestaurant($custID,$restID)
		{
			$params=array(
			':custID'=>$custID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("delete from favouriteorderoption where 
			ffID in (select ffID from favouritefood where custID=:custID and restID=:restID)");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favouritefood where 
			custID=:custID and restID=:restID");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favouritechoiceoption where
			fscID in (select fscID from favouritesetchoice where
			fsID in (select fsID from favouriteset where
			custID=:custID and restID=:restID)
			)");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favouritesetchoice where
			fsID in (select fsID from favouriteset where 
			custID=:custID and restID=:restID)");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favouriteset where 
			custID=:custID and restID=:restID");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favourite where 
			custID=:custID and restID=:restID");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function deleteFavouriteFood($foodID)
		{
			$params=array(
			':foodID'=>$foodID
			);
			
			$stmt=$this->conn->prepare("delete from favouriteorderoption where
			ffID in (select ffID from favouritefood where
			foodID=:foodID)");
			$result=$stmt->execute($params);
			$stmt=$this->conn->prepare("delete from favouritefood where 
			foodID=:foodID");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function deleteFavouriteSet($setID)
		{
			$params=array(
			':setID'=>$setID
			);
			
			$stmt=$this->conn->prepare("delete from favouritechoiceoption where 
			fscID in (select fscID from favouritesetchoice where 
			fsID in (select fsID from favouriteset where 
			setID=:setID)
			)");
			$result=$stmt->execute($params);
			$stmt=$this->conn->prepare("delete from favouritesetchoice where 
			fsID in (select fsID from favouriteset where
			setID=:setID)");
			$result=$stmt->execute($params);
			$stmt=$this->conn->prepare("delete from favouriteset where
			setID=:setID");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
	}
?>