<?php
	class DbOperation
	{
		private $conn;
		
		function __construct()
		{
			require_once dirname(__FILE__) . '/conn.php';
			
			$db=new DbConnect();
			$this->conn=$db->connect();
			
			set_exception_handler('errorBlock');
		}
		
		public function __call($name, $args)
		{
			$name = $name . "_" . implode("_", array_map("gettype", $args)));
			return call_user_func_array(array($this, $name), $args);
		}
		
		public function errorBlock($e)
		{
			$msg=array('result'=>500,'message'=>"sql error",'data'=>$ex->getMessage());
			echo json_encode($msg, JSON_UNESCAPED_UNICODE);
			return false;
		}
		
		public function getCustomer()
		{
			$stmt=$this->conn->prepare("select * from customer");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerID()
		{
			$stmt=$this->conn->prepare("select custID from customer 
			ORDER BY custID DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerNoticeID()
		{
			$stmt=$this->conn->prepare("select cNID from custnotice 
			ORDER BY cNID DESC LIMIT 1");
			$stmt->execute();
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSmsByPhone($phoneNo)
		{
			$params=array(
			':phoneNo'=>$phoneNo
			);
			
			$stmt=$this->conn->prepare("select * from sms where
			phone=:phoneNo' order by id desc limit 1");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerByPhone($phoneNo)
		{
			$params=array(
			':phoneNo'=>$phoneNo
			);
			
			$stmt=$this->conn->prepare("select * from customer where 
			custTel=:phoneNo");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerByDevice($custDevice)
		{
			$params=array(
			':custDevice'=>password_hash($custDevice, PASSWORD_BCRYPT)
			);
			
			$stmt=$this->conn->prepare("select * from customer where
			custDevice=:custDevice");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getRestaurantCharge($restID)
		{
			$params=array(
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from charge where 
			restID=:restID and hide='0'
			order by orderIn");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteRestaurant($custID,$restID)
		{
			$params=array(
			':custID'=>$custID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from favourite where
			custID=:custID and restID=:restID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteFood($custID,$foodID)
		{
			$params=array(
			':custID'=>$custID,
			':foodID'=>$foodID
			);
			
			$stmt=$this->conn->prepare("select * from favouritefood where 
			custID=:custID and foodID=:foodID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteFood($custID,$setID)
		{
			$params=array(
			':custID'=>$custID,
			':setID'=>$setID
			);
			
			$stmt=$this->conn->prepare("select * from favouriteset where
			custID=:custID and setID=:setID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerFavouriteRestaurant($custID)
		{
			$params=array(
			':custID'=>$custID
			);
			
			$stmt=$this->conn->prepare("select * from favourite where 
			custID=:custID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getRestaurant($restID)
		{
			$params=array(
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from restcompany,restaurant,region where
			region.rgid=restaurant.rgid and
			restcompany.companyID=restaurant.companyID and 
			restaurant.restID=:restID and
			restaurant.locked=0 and
			restcompany.locked=0");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerFavouriteFood($custID,$restID)
		{
			$params=array(
			':custID'=>$custID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("
			select * from restaurant,favouritefood,restcompany,menugroup,menugroupitem where
			menugroup.groupNo=menugroupitem.groupNo and
			menugroup.restID=menugroupitem.restID and
			menugroupitem.foodID=favouritefood.foodID and
			restcompany.companyID=restaurant.companyID and
			restaurant.restID=favouritefood.restID and
			favouritefood.custID=:custID and 
			favouritefood.restID=:restID and 
			restaurant.locked=0 and
			restcompany.locked=0");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getMenuItemFood($foodID,$restID)
		{
			$params=array(
			':foodID'=>$foodID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from food,menugroupitem where 
			menugroupitem.foodID=food.foodID and 
			available=0 and 
			food.foodID=:foodID and
			food.restID=:restID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteOrderOption($ffID)
		{
			$params=array(
			':ffID'=>$ffID
			);
			
			$stmt=$this->conn->prepare("select * from favouriteorderoption where
			ffID=:ffID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSpecialOption($optID)
		{
			$params=array(
			':optID'=>$optID
			);
			
			$stmt=$this->conn->prepare("select * from specialoption where 
			optID=:optID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerFavouriteSet($custID,$restID)
		{
			$params=array(
			':custID'=>$custID,
			':optID'=>$optID
			);
			
			$stmt=$this->conn->prepare("
			select * from restaurant,favouriteset,restcompany,menugroup,menugroupitem where 
			menugroup.groupNo=menugroupitem.groupNo and 
			menugroup.restID=menugroupitem.restID and 
			menugroupitem.setID=favouriteset.setID and
			restcompany.companyID=restaurant.companyID and
			restaurant.restID=favouriteset.restID and
			custID=:custID and 
			favouriteset.restID=:restID and
			restaurant.locked=0 and 
			restcompany.locked=0");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getMenuItemFood($setID,$restID)
		{
			$params=array(
			':setID'=>$setID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("select * from setitem,menugroupitem where 
			menugroupitem.setID=setitem.setID and 
			available=0 and 
			setitem.setID=:setID and
			setitem.restID=:restID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getSetTitle($setID)
		{
			$params=array(
			':setID'=>$setID
			);
			
			$stmt=$this->conn->prepare("select * from settitle where 
			setID=:setID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getCustomerFavouriteSetChoice($fsID,$custID)
		{
			$params=array(
			':fsID'=>$fsID,
			':custID'=>$custID
			);
			
			$stmt=$this->conn->prepare("select * from favouritesetchoice where
			fsID=:fsID and
			custID=:custID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getMenuItemSetFood($titleNo)
		{
			$params=array(
			':titleNo'=>$titleNo
			);
			
			$stmt=$this->conn->prepare("select * from food,setfood,menugroupitem where
			menugroupitem.foodID=food.foodID and
			available=0 and 
			food.foodID=setfood.foodID and 
			setfood.titleNo=:titleNo");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getFavouriteChoiceOption($fscID)
		{
			$params=array(
			':fscID'=>$fscID
			);
			
			$stmt=$this->conn->prepare("select * from favouritechoiceoption where 
			fscID=:fscID");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function getMenuItemSetFood($setID,$titleNo)
		{
			$params=array(
			':setID'=>$setID,
			':titleNo'=>$titleNo
			);
			
			$stmt=$this->conn->prepare("select * from food,setfood,menugroupitem where
			menugroupitem.foodID=food.foodID and
			available=0 and 
			food.foodID=setfood.foodID and 
			setfood.setID=:setID and
			setfood.titleNo=:titleNo");
			$stmt->execute($params);
			$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
			return $result;
		}
		
		public function createCust($custID,$custDevice,$custTel)
		{
			$params=array(
			':custID'=>$custID,
			':custDevice'=>password_hash($custDevice,PASSWORD_BCRYPT),
			':custTel'=>$custTel
			);
			
			$stmt=$this->conn->prepare("insert into customer(custID,custDevice,custTel) values 
			(:custID,:custDevice,:custTel)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createSMS($phone,$verifyCode)
		{
			$params=array(
			':phone'=>$phone,
			':verifyCode'=>$verifyCode
			);
			
			$stmt=$this->conn->prepare("insert into sms(phone,verifyCode) values 
			(:phoneNo,:verifyCode)");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function createCustomerNotice($cNID,$custID,$title,$titleEng,$description,$descriptionEng)
		{
			$params=array(
			':cNID'=>$cNID,
			':custID'=>$custID,
			':title'=>$title,
			':titleEng'=>$titleEng,
			':description'=>$description,
			':descriptionEng'=>$descriptionEng
			);
			
			$stmt=$this->conn->prepare("
			insert into custnotice(cNID,custID,title,titleEng,description,descriptionEng) values 
			(:cNID,:custID,:title,:titleEng,:description,:descriptionEng)"; 
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function deleteSmsByPhone($phone)
		{
			$params=array(
			':phone'=>$phone
			);
			
			$stmt=$this->conn->prepare("delete from sms where 
			phone=:phone");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function deleteFavouriteRestaurant($custID,$restID)
		{
			$params=array(
			':custID'=>$custID,
			':restID'=>$restID
			);
			
			$stmt=$this->conn->prepare("delete from favouriteorderoption where 
			ffID in (select ffID from favouritefood where custID=:custID and restID=:restID)");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favouritefood where 
			custID=:custID and restID=:restID");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favouritechoiceoption where
			fscID in (select fscID from favouritesetchoice where
			fsID in (select fsID from favouriteset where
			custID=:custID and restID=:restID)
			)");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favouritesetchoice where
			fsID in (select fsID from favouriteset where 
			custID=:custID and restID=:restID)");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favouriteset where 
			custID=:custID and restID=:restID");
			$result=$stmt->execute($params);
			
			$stmt=$this->conn->prepare("delete from favourite where 
			custID=:custID and restID=:restID");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function deleteFavouriteFood($foodID)
		{
			$params=array(
			':foodID'=>$foodID
			);
			
			$stmt=$this->conn->prepare("delete from favouriteorderoption where
			ffID in (select ffID from favouritefood where
			foodID=:foodID)");
			$result=$stmt->execute($params);
			$stmt=$this->conn->prepare("delete from favouritefood where 
			foodID=:foodID");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
		
		public function deleteFavouriteSet($setID)
		{
			$params=array(
			':setID'=>$setID
			);
			
			$stmt=$this->conn->prepare("delete from favouritechoiceoption where 
			fscID in (select fscID from favouritesetchoice where 
			fsID in (select fsID from favouriteset where 
			setID=:setID)
			)");
			$result=$stmt->execute($params);
			$stmt=$this->conn->prepare("delete from favouritesetchoice where 
			fsID in (select fsID from favouriteset where
			setID=:setID)");
			$result=$stmt->execute($params);
			$stmt=$this->conn->prepare("delete from favouriteset where
			setID=:setID");
			$result=$stmt->execute($params);
			$stmt->close();
			if($result){
				return true;
				}else{
				return false;
			}
		}
	}
?>